import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import GetMahasiswa from './Components/Admin/GetMahasiswa';
import CreateMahasiswa from './Components/Admin/CreateMahasiswa';


function App() {
  
  return (
    <>
      <Router>
        <Routes>
          <Route path='/GetMahasiswa' element={ <GetMahasiswa /> } />
          <Route path='/CreateMahasiswa' element={ <CreateMahasiswa/> } />
        </Routes>
      </Router>
    </>
  )
}

export default App
